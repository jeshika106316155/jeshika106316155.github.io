// MI_LIB.cpp: �D�n�M���ɡC
#include "stdafx.h"
using namespace std;

int main(array<System::String ^> ^args)
{
	printf("Dictionary loaded...\n");
	LoadDictionary("dd.txt");   // DICOM tags and VR dictionary
	DICOMDataObject DDO;  // DICOM Decode Objact
 /*   char str[] = "d:\\img\\CT1.dcm";
   char str2[] = "d:\\img\\CT1.xml";
   DDO.ReadDICOMFileObject(str, 0, false, true);  */

  
   char str[] = "d:\\img\\2018\\NEMA_Brain\\IM_0050";
    char str2[] = "d:\\img\\2018\\NEMA_Brain\\IM_0050.xml";
   	DDO.ReadDICOMPart10File(str);
	DDO.DecodeRetToXML(str2);
   //int ReadDICOMFileObject(char * FileName, unsigned int DDOOffset, bool inIsExplicitVR,bool inIsLittleEanian);
	//DDO.ReadDICOMFileObject(str, 0, false, true);
 	getchar();
	return 0;
}
