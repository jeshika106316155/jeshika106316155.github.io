unsigned int DICOMObjectCount;
void InitFunction()
{
	DICOMObjectCount =0;

}
