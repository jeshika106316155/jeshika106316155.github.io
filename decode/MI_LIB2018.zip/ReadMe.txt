read DICOM part10 file 
DICOMDataObject:: bool ReadDICOMPart10File(char *FileName);
�Y�D part10 file �����D(�q) �� VR and Endian `, DDOOffset �@�묰 0
DICOMDataObject:: bool ReadDICOMFileObject(char * FileName, unsigned int DDOOffset, bool inIsExplicitVR,bool inIsLittleEndian);  // if we can know (guest) transfer syntax, such that in association processes 
